#NIM/Nama : 16522076/Kayla Nasywa V
#F01 - Login

def login(nama_file):
    import csv
    login = False

    while not(login):
        data=[]
        with open(nama_file) as csvfile:
            reader = csv.reader(csvfile, delimiter=";")
            for row in reader:
                data.append(row)

        username = input("Username: ")
        password = input("Password: ")

        col0 = [x [0] for x in data]
        col1 = [x [1] for x in data]
        
        if username in col0:
            for k in range(0, len(col0)):
                if col0[k] == username and col1[k] == password:
                    print("Selamat datang, " + username + "!")
                    print("Masukkan command " + "help" +" untuk daftar command yang dapat kamu panggil.")
                    login = True
                elif col0[k] == username and col1[k] != password:
                    print("Password salah!")

        else:
                    print("Username tidak terdaftar!")



