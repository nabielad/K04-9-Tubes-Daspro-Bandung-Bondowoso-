import argparse


def argument_Parse():
    kondisi = False
    
    parser = argparse.ArgumentParser(description="Tidak ada nama folder yang diberikan!", usage="python main.py <nama_folder>")

    parser.add_argument("nama_Folder", metavar="<nama_Folder>", help="Tidak ada nama folder yang diberikan!")

    args = parser.parse_args()

    if( args.nama_Folder == "TuBes"):
        print("Loading...")
        print('selamat datang di progrm "Manajerial Candi"')
        kondisi = True
    else:
        print('Folder "'+args.nama_Folder+'" tidak ditemukan.')

    return kondisi