#NIM/Nama : 16522076/Kayla Nasywa V
#F02 - Logout

x = True
while x == True:
    print("""
    1. logout
       Untuk keluar dari akun yang digunakan sekarang
    ...
    """)
    pilihan = int(input("Pilihan: "))
    if pilihan == 1:
        break
        login()

    
