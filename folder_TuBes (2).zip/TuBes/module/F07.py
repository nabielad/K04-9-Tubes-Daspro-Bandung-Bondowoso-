import random

# F07 - Jin Pengumpul
# 16522031 - Aditia Fortuna

jumlah_candi = 0
jumlah_pasir = 0
jumlah_batu = 0
jumlah_air = 0

def kumpul():
    global jumlah_pasir
    global jumlah_batu
    global jumlah_air

    pasir = random.randint(1,5)
    batu = random.randint(1,5)
    air = random.randint(1,5)

    jumlah_pasir += pasir
    jumlah_batu += batu
    jumlah_air += air

    print(f"Jin menemukan {pasir} pasir, {batu} batu, dan {air} air.")

