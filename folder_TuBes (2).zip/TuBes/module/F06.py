import random

# F06 - Jin Pembangun
# 16522031 - Aditia Fortuna

jumlah_candi = 0
jumlah_pasir = 0
jumlah_batu = 0
jumlah_air = 0

def bangun():
    global jumlah_candi
    global jumlah_pasir
    global jumlah_batu
    global jumlah_air

    pasir = random.randint(1,5)
    batu = random.randint(1,5)
    air = random.randint(1,5)

    if jumlah_candi >= 100:
        jumlah_pasir -= pasir
        jumlah_batu -= batu
        jumlah_air -= air
        print("Candi berhasil dibangun.")
        print(f"Sisa candi yang perlu dibangun: 0.")
    elif (jumlah_pasir > pasir) or (jumlah_batu > batu) or (jumlah_air > air):
        print("Bahan bangunan tidak mencukupi.")
        print("Candi tidak bisa dibangun!")
    else:
        jumlah_candi -= 1
        jumlah_pasir -= pasir
        jumlah_batu -= batu
        jumlah_air -= air
        print("Candi berhasil dibangun.")
        print(f"Sisa candi yang perlu dibangun: {100 - jumlah_candi}.")
