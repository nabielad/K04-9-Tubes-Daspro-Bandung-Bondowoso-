users = [] # Matriks data user
candi = [] # Matriks data candi
bahan = [] # Data bahan bangunan
jumlah_candi = 0
logged_in = False
current_user = ("", "", "")
current_directory = ""