import commands
from modules import F01
from modules import F13

F13.load()
F01.login()
print("Silahkan masukkan username Anda")

while True:
  masukan = input(">>> ")
  commands.run(masukan)