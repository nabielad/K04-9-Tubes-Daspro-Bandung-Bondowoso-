from modules import F01
from modules import F02
from modules import F03
from modules import F04
from modules import F05
from modules import F06
from modules import F07
from modules import F08
from modules import F09
from modules import F10
from modules import F11
from modules import F12
from modules import F13
from modules import F14
from modules import F15
from modules import F16
import variables as var

def run(masukan):
    if masukan == "login":
        F01.login()
    elif masukan == "logout":
        F02.logout()
    elif masukan == "summonjin":
        F03.summonjin() if var.current_user[2] == "bandung_bondowoso" else print("Summon jin hanya dapat diakses oleh akun Bandung Bondowoso.")
    elif masukan == "hapusjin":
        F04.hapusjin() if var.current_user[2] == "bandung_bondowoso" else print("Hapus jin hanya dapat diakses oleh akun Bandung Bondowoso.")
    elif masukan == "ubahjin":
        F05.ubahjin() if var.current_user[2] == "bandung_bondowoso" else print("Ubah jin hanya dapat diakses oleh akun Bandung Bondowoso.")
    elif masukan == "bangun":
        F06.bangun() if var.current_user[2] == "jin_pembangun" else print("Hapus jin hanya dapat diakses oleh akun jin pembangun.")
    elif masukan == "kumpul":
        F07.kumpul() if var.current_user[2] == "jin_pengumpul" else print("Hapus jin hanya dapat diakses oleh akun jin pengumpul.")
    elif masukan == "batchkumpul":
        F08.batchkumpul() if var.current_user[2] == "bandung_bondowoso" else print("Batch kumpul hanya dapat diakses oleh akun Bandung Bondowoso.")
    elif masukan == "batchbangun":
        F08.batchbangun() if var.current_user[2] == "bandung_bondowoso" else print("Batch bangun hanya dapat diakses oleh akun Bandung Bondowoso.")
    elif masukan == "laporanjin":
        F09.laporanjin() if var.current_user[2] == "bandung_bondowoso" else print("Laporan jin hanya dapat diakses oleh akun Bandung Bondowoso.")
    elif masukan == "laporancandi":
        F10.laporancandi() if var.current_user[2] == "bandung_bondowoso" else print("Laporan candi hanya dapat diakses oleh akun Bandung Bondowoso.")
    elif masukan == "hancurkancandi":
        F11.hancurkancandi() if var.current_user[2] == "roro_jonggrang" else print("Hancurkan candi hanya dapat diakses oleh akun Roro Jonggrang.")
    elif masukan == "ayamberkokok":
        F12.ayamberkokok() if var.current_user[2] == "roro_jonggrang" else print("Ayam berkokok hanya dapat diakses oleh akun Roro Jonggrang.")
    elif masukan == "save":
        F14.save()
    elif masukan == "help":
        F15.help()
    elif masukan == "exit":
        F16.exit()
    else:
        print("command tidak valid")