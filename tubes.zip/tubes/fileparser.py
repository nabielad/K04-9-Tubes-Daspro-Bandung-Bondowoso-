def split_line(li):
# fungsi untuk memisahkan line menjadi list
    num = delimiter_num(li) + 1
    out_list = [None for i in range(num)]
    for i in range(num):
        out_list[i] = ambil_data(li, i)
    return out_list

def delimiter(li, n):
# fungsi untuk menentukan posisi delimiter dalam suatu line
    idx = 0
    cnt = 0
    while li[idx] != '\n' and cnt != n:
        if li[idx] == ';':
            cnt += 1
        idx += 1
    return idx

def delimiter_num(li):
# fungsi untuk menentukan banyak delimiter dalam suatu line
    idx = 0
    cnt = 0
    while li[idx] != '\n':
        if li[idx] == ';':
            cnt += 1
        idx += 1
    return cnt

def ambil_data(li, n):
# fungsi untuk mengambil data dari suatu line
    idx = delimiter(li, n)
    data = ""
    while (li[idx] != ';') and (li[idx] != '\n'):
        data += li[idx]
        idx += 1
    return data

def open_csv(input_csv):
# fungsi untuk mengubah csv menjadi array
    file = open(input_csv)
    out_list = [None for i in range(250)]
    cnt = 0
    while True:
        csv_line = file.readline()
        if csv_line == "":
            break
        else:
            csv_data = split_line(csv_line)
            out_list[cnt] = csv_data
        cnt += 1
    file.close()
    return out_list



def write_csv(input_data, csv_to_write):
# fungsi untuk mengubah array menjadi csv
    csv_data = open(csv_to_write, 'w')
    for idx in range(101):
        if input_data[idx] != None:
            csv_data.writelines(';'.join(input_data[idx]))
            csv_data.write("\n")
    csv_data.close()
