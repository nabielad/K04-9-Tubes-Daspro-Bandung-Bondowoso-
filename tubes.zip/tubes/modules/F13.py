import argparse
import os
import variables as var
import fileparser

def load():
    parser = argparse.ArgumentParser(usage="python main.py <nama_folder>")
    parser.add_argument("nama_folder")
    args = parser.parse_args()

    folder = "save/" + args.nama_folder
    var.current_directory = folder

    if os.path.exists(folder):
        print("\nLoading...")
        load_data(folder)
        sort_candi()
        print("\nSelamat datang di program “Manajerial Candi“")
    else:
        print("\nFolder “" + args.nama_folder + "“ tidak ditemukan.")
        quit()

def load_data(folder):
    var.bahan = fileparser.open_csv(folder + "/bahan_bangunan.csv")
    var.candi = fileparser.open_csv(folder + "/candi.csv")
    var.users = fileparser.open_csv(folder + "/user.csv")

def sort_candi():
    temp_candi = [None for i in range(101)]
    temp_candi[0] = var.candi[0]
    for i in range (1, 101):
        for j in range(1, 101):
            if var.candi[j] != None:
                if var.candi[j][0] == str(i):
                    temp_candi[i] = var.candi[j]
                    var.jumlah_candi += 1
                    break
    var.candi = temp_candi

