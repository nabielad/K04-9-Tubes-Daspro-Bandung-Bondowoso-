import os
import variables as var
import fileparser

def exit():
    file_bahan = var.current_directory + "/bahan_bangunan.csv"
    file_candi = var.current_directory + "/candi.csv"
    file_users = var.current_directory + "/user.csv"
    while True:
        pilih = input("Apakah Anda mau melakukan penyimpanan file yang sudah diubah? (Y/N) ")
        if pilih == 'Y':
            write_save(file_bahan, file_candi, file_users)
            quit()
        elif pilih == 'N':
            quit()
        else:
            True

def write_save(file_bahan, file_candi, file_users):
    fileparser.write_csv(var.bahan, file_bahan)
    fileparser.write_csv(var.candi, file_candi)
    fileparser.write_csv(var.users, file_users)
