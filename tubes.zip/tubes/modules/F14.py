import os
import variables as var
import fileparser

def save():
    folder_name = input("Masukkan nama folder:")

    file_bahan = "save/" + folder_name + "/bahan_bangunan.csv"
    file_candi = "save/" + folder_name + "/candi.csv"
    file_users = "save/" + folder_name + "/user.csv"

    if os.path.exists("save"):
        if os.path.exists("save/"+folder_name):
            write_save(file_bahan, file_candi, file_users)
            print("\nSaving...\n\nBerhasil menyimpan data di folder save/" + folder_name + "!")
        else:
            os.mkdir("save/" + folder_name)
            print("\nSaving...\n\nMembuat di folder save/" + folder_name + "...")
            write_save(file_bahan, file_candi, file_users)
            print("\nBerhasil menyimpan data di folder save/" + folder_name + "!")
    else:
        os.mkdir("save/")
        os.mkdir("save/" + folder_name)
        print("\nSaving...")
        write_save(file_bahan, file_candi, file_users)

def write_save(file_bahan, file_candi, file_users):
    fileparser.write_csv(var.bahan, file_bahan)
    fileparser.write_csv(var.candi, file_candi)
    fileparser.write_csv(var.users, file_users)
