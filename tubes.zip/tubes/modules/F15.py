import variables as var

def help():
    print("=========== HELP ===========")
    if var.current_user[2] == "bandung_bondowoso":
        print("1. logout\n   Untuk keluar dari akun yang digunakan sekarang")
        print("2. summonjin\n   Untuk memanggil jin")
        print("3. ubahjin\n   Untuk mengubah tipe jin")
        print("4. batchkumpul\n   Untuk mengumpulkan resource candi dengan semua jin yang tersedia")
        print("5. batchbangun\n   Untuk membangun candi dengan semua jin yang tersedia")
        print("6. laporanjin\n   Untuk membuat laporan kondisi jin")
        print("7. laporancandi\n   Untuk membuat laporan kondisi candi")
        print("8. save\n   Untuk menyimpan progres permainan")
        print("9. help\n   Untuk memberi bantuan list command")
        print("10.exit\n   Untuk keluar dari program dan kembali ke terminal")
    elif var.current_user[2] == "roro_jonggrang":
        print("1. logout\n   Untuk keluar dari akun yang digunakan sekarang")
        print("2. hancurkancandi\n   Untuk menghancurkan candi yang tersedia")
        print("3. ayamberkokok\n   Untuk mengakhiri permainan")
        print("4. save\n   Untuk menyimpan progres permainan")
        print("5. help\n   Untuk memberi bantuan list command")
        print("6. exit\n   Untuk keluar dari program dan kembali ke terminal")
    elif var.current_user[2] == "jin_pembangun":
        print("1. login\n   Untuk masuk menggunakan akun")
        print("2. help\n   Untuk memberi bantuan list command")
        print("3. bangun\n   Untuk membangun candi")
        print("4. exit\n   Untuk keluar dari program dan kembali ke terminal")
    elif var.current_user[2] == "jin_pengumpul":
        print("1. login\n   Untuk masuk menggunakan akun")
        print("2. help\n   Untuk memberi bantuan list command")
        print("3. kumpul\n   Untuk Untuk mengumpulkan resource candi")
        print("4. exit\n   Untuk keluar dari program dan kembali ke terminal")
    else:
        print("1. login\n   Untuk masuk menggunakan akun")
        print("2. help\n   Untuk memberi bantuan list command")
        print("3. exit\n   Untuk keluar dari program dan kembali ke terminal")
