import variables as var
def hapusjin():
    username = input("Masukkan username jin: ")
    username_exist = False

    for idx in range(1, 101):
        if var.users[idx] != None:
            if username == var.users[idx][0]:
                idx_jin = idx
                username_exist = True
            
    if username_exist:
        while True:
            pilih = input("Apakah anda yakin ingin menghapus jin dengan username " + str(username) + " (Y/N)? ")
            if pilih == 'Y':
                var.users[idx_jin] = None
                hapus_candi(username)
                print("\nJin telah berhasil dihapus dari alam gaib.")
                break
            elif pilih == 'N':
                print("\nJin batal dihapus dari alam gaib.")
                break
            else:
                print("\nMasukan tidak valid.")
    else:
        print("Tidak ada jin dengan username tersebut.")

def hapus_candi(username):
    for idx in range(1, 101):
        if var.candi[idx] != None:
            if username == var.candi[idx][1]:
                var.candi[idx] = None