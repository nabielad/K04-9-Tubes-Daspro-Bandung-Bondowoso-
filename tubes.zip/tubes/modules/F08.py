import variables as var
from random import randint

def batchkumpul():
    jumlah_jin = 0
    jumlah_pasir = 0
    jumlah_batu = 0
    jumlah_air = 0

    for idx in range(1, 101):
        if var.users[idx] == None:
            continue
        
        if var.users[idx][2] == "jin_pengumpul":
            jumlah_jin += 1
            jumlah_pasir += randint(1,5)
            jumlah_batu += randint(1,5)
            jumlah_air += randint(1,5)
    
    var.bahan[1][2] = int(var.bahan[1][2]) + jumlah_pasir
    var.bahan[2][2] = int(var.bahan[2][2]) + jumlah_batu
    var.bahan[3][2] = int(var.bahan[3][2]) + jumlah_air
    
    if jumlah_jin == 0:
        print("Kumpul gagal. Anda tidak punya jin pengumpul. Silahkan summon terlebih dahulu.")
    else:
        print("Mengerahkan " + str(jumlah_jin) + " jin untuk mengumpulkan bahan.")
        print("Jin menemukan total " + str(jumlah_pasir) + " pasir, " + str(jumlah_batu) + " batu, dan " + str(jumlah_air) + " air.")

def batchbangun():
    jumlah_jin = 0
    jumlah_pasir = 0
    jumlah_batu = 0
    jumlah_air = 0

    candi_tmp = [None for i in range(100)]
    i = 0

    for idx in range(1, 101):
        if var.users[idx] == None:
            continue
        if var.users[idx][2] == "jin_pembangun":
            pasir = randint(1,5)
            batu = randint(1,5)
            air = randint(1,5)
            
            jumlah_jin += 1
            jumlah_pasir += pasir
            jumlah_batu += batu
            jumlah_air += air

            candi_tmp[i] = [var.users[idx][0], pasir, batu, air]

            i += 1
            var.jumlah_candi += 1
    
    if jumlah_jin == 0:
        print("Bangun gagal. Anda tidak punya jin pembangun. Silahkan summon terlebih dahulu.")
    else:
        print("Mengerahkan " + str(jumlah_jin) + " jin untuk membangun candi dengan total bahan "+ str(jumlah_pasir) + " pasir, " + str(jumlah_batu) + " batu, dan " + str(jumlah_air) + " air.")
    
        if jumlah_pasir > int(var.bahan[1][2]) or jumlah_batu > int(var.bahan[2][2]) or jumlah_air > int(var.bahan[3][2]):
            pasir = 0 if (jumlah_pasir < int(var.bahan[1][2])) else (jumlah_pasir - int(var.bahan[1][2]))
            batu = 0 if (jumlah_batu < int(var.bahan[2][2])) else (jumlah_batu - int(var.bahan[2][2]))
            air = 0 if (jumlah_air < int(var.bahan[3][2])) else (jumlah_air - int(var.bahan[3][2]))
            print("Bangun gagal. Kurang " + str(pasir) + " pasir, " + str(batu) + " batu, dan " + str(air) + " air.")
        else:
            i = 0
            var.bahan[1][2] = str(int(var.bahan[1][2]) - jumlah_pasir)
            var.bahan[2][2] = str(int(var.bahan[2][2]) - jumlah_batu)
            var.bahan[3][2] = str(int(var.bahan[3][2]) - jumlah_air)
            for idx in range(1,101):
                if candi_tmp[i] == None:
                        break
                if var.candi[idx] == None:
                    var.candi[idx] = [str(idx),
                                      str(candi_tmp[i][0]),
                                      str(candi_tmp[i][1]),
                                      str(candi_tmp[i][2]),
                                      str(candi_tmp[i][3])]
                    i += 1
