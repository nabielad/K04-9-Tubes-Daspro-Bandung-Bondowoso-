import variables as var

def laporancandi():
    total_pasir = 0
    total_batu = 0
    total_air = 0

    id_candi_termahal = 0
    biaya_candi_termahal = 0
    id_candi_termurah = 0
    biaya_candi_termurah = 999999999

    for idx in range(1, 101):
        if var.candi[idx] != None:
            biaya = 10000 * int(var.candi[idx][2]) + 15000 * int(var.candi[idx][3]) + 7500 * int(var.candi[idx][4])
            if biaya > biaya_candi_termahal:
                biaya_candi_termahal = biaya
                id_candi_termahal = idx
            if biaya < biaya_candi_termurah:
                biaya_candi_termurah = biaya
                id_candi_termurah = idx

            total_pasir += int(var.candi[idx][2])
            total_batu += int(var.candi[idx][3])
            total_air += int(var.candi[idx][4])
    
    print("\n> Total Candi: " + str(var.jumlah_candi))
    print("> Total Pasir yang digunakan: " + str(total_pasir))
    print("> Total Batu yang digunakan: " + str(total_batu))
    print("> Total Air yang digunakan: " + str(total_air))
    if var.jumlah_candi == 0:
        print("> ID Candi Termahal: -")
        print("> ID Candi Termurah: -")
    else:
        print("> ID Candi Termahal: " + str(id_candi_termahal) + separator(biaya_candi_termahal))
        print("> ID Candi Termurah: " + str(id_candi_termurah) + separator(biaya_candi_termurah))

def separator(biaya):
    biaya_separated = ""
    num = 0
    while biaya:
        num += 1
        biaya_separated = str(biaya % 10) + biaya_separated
        if num == 3 and (biaya // 10):
            biaya_separated = "." + biaya_separated
            num = 0
        biaya //= 10
    biaya_separated = " (Rp " + biaya_separated + ")"
    return biaya_separated
