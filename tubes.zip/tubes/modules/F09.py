import variables as var

def laporanjin():
    jumlah_jin = 0
    jumlah_jin_pengumpul = 0
    jumlah_jin_pembangun = 0

    for idx in range(1,101):
        if var.users[idx] != None:
            if var.users[idx][2] == "jin_pengumpul":
                jumlah_jin += 1
                jumlah_jin_pengumpul += 1
            elif var.users[idx][2] == "jin_pembangun":
                jumlah_jin += 1
                jumlah_jin_pembangun += 1
    
    list_jin = list_jin_pembangun()
    jin_terajin = list_jin[0][0]
    jin_termalas = list_jin[0][0]

    idx = 1
    mini = list_jin[0][1]
    maks = list_jin[0][1]

    while list_jin[idx] != None:
        if list_jin[idx][1] > maks:
            maks = list_jin[idx][1]
            jin_terajin = list_jin[idx][0]
        if list_jin[idx][1] <= mini:
            mini = list_jin[idx][1]
            jin_termalas = list_jin[idx][0]
        idx += 1
    
    print("\n> Total Jin: " + str(jumlah_jin))
    print("> Total Jin Pengumpul: " + str(jumlah_jin_pengumpul))
    print("> Total Jin Pembangun: " + str(jumlah_jin_pembangun))
    print("> Jin Terajin: " + str(jin_terajin))
    print("> Jin Termalas: " + str(jin_termalas))
    print("> Jumlah Pasir: " + str(var.bahan[1][2]) + " unit")
    print("> Jumlah Batu: " + str(var.bahan[2][2]) + " unit")
    print("> Jumlah Air: " + str(var.bahan[3][2]) + " unit")
    
    
def list_jin_pembangun():
    list_jin = [None for i in range(100)]
    i = 0
    for idx in range(1,101):
        if var.users[idx] != None:
            if var.users[idx][2] == "jin_pembangun":
                list_jin[i] = [var.users[idx][0], 0]
                i += 1
    
    for i in range(100):
        if list_jin[i] != None:
            for j in range(1,101):
                if var.candi[j] != None:
                    if list_jin[i][0] == var.candi[j][1]:
                        list_jin[i][1] += 1

    list_jin = sort_list(list_jin)
    return list_jin
    

def sort_list(li):
    len = 0
    while li[len] != None:
        len += 1
    
    for i in range(len):
        for j in range(0, len - i - 1):
            if li[j][0] > li[j + 1][0]:
                temp = li[j]
                li[j] = li[j+1]
                li[j+1] = temp
    return li
