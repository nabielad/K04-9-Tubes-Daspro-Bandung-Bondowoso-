import variables as var

def ayamberkokok():
    print("Kukuruyuk.. Kukuruyuk..")
    print("\nJumlah Candi: " + str(var.jumlah_candi))
    if var.jumlah_candi == 100:
        print("\nYah, Bandung Bondowoso memenangkan permainan!")
    else:
        print("\nSelamat, Roro Jonggrang memenangkan permainan!")
        print("\nBandung Bondowoso angry noise*")
        print("Roro Jonggrang dikutuk menjadi candi.")
    quit()