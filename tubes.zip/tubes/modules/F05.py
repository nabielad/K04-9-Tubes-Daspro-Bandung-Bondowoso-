import variables as var

def ubahjin():
    username = input("Masukkan username jin: ")
    username_exist = False

    for idx in range(1, 101):
        if var.users[idx] != None:
            if username == var.users[idx][0]:
                username_exist = True
                idx_jin = idx
            
    if username_exist:
        role = var.users[idx_jin][2]
        if role == "jin_pengumpul":
            while True:
                pilih = input("Jin ini bertipe “Pengumpul”. Yakin ingin mengubah ke tipe “Pembangun” (Y/N)? ")
                if pilih == 'Y':
                    var.users[idx_jin][2] = "jin_pembangun"
                    print("\nJin telah berhasil diubah.")
                    break
                elif pilih == 'N':
                    print("\nJin tidak diubah.")
                    break
                else:
                    print("\n Masukkan tidak valid")
        elif role == "jin_pembangun":
            while True:
                pilih = input("Jin ini bertipe “Pembangun”. Yakin ingin mengubah ke tipe “Pengumpul” (Y/N)? ")
                if pilih == 'Y':
                    var.users[idx_jin][2] = "jin_pengumpul"
                    print("\nJin telah berhasil diubah.")
                    break
                elif pilih == 'N':
                    print("\nJin tidak diubah.")
                    break
                else:
                    print("\n Masukkan tidak valid")
                
    else:
        print("Tidak ada jin dengan username tersebut.")
