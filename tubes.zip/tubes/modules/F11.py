import variables as var

def hancurkancandi():
    id_candi = input("Masukkan ID candi: ")
    id_candi_exist = False

    for idx in range(1, 101):
        if var.candi[idx] != None:
            if id_candi == var.candi[idx][0]:
                id_candi_exist = True
                idx_candi = idx
            
    if id_candi_exist:
        while True:
            pilih = input("Apakah anda yakin ingin menghancurkan candi ID: " + str(id_candi) + " (Y/N)? ")
            if pilih == 'Y':
                var.candi[idx_candi] = None
                print("\nCandi telah berhasil dihancurkan.")
                break
            elif pilih == 'N':
                print("\nCandi batal dihancurkan.")
                break
            else:
                print("\nMasukan tidak valid.")

    else:
        print("\nTidak ada candi dengan ID tersebut.")